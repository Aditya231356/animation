from flask import Flask, render_template, request, redirect, url_for, flash, session
import sqlite3
import os
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key' # IMPORTANT: Change this to a strong, random key

DB_FILE = os.path.join(os.path.dirname(__file__), 'users.db')

# ---------- Initialize DB ----------
def init_db():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL
        )
    ''')
    # Add other table creations here if not using a separate database.py for initial setup
    # For example, if database.py is not run separately, you'd put the CREATE TABLE statements here.
    conn.commit()
    conn.close()

# Helper function to get user ID from session
def get_user_id_from_session():
    if 'user' in session:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM users WHERE full_name=?", (session['user'],))
        user_id = cursor.fetchone()
        conn.close()
        if user_id:
            return user_id[0]
    return None

# ---------- Home Page ----------
@app.route('/')
def home():
    return render_template("my_project.html")

# ---------- Register ----------
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        full_name = request.form['name'] # Changed from 'full_name' to 'name' to match register.html
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm'] # Added confirm password check

        if password != confirm_password:
            flash("Passwords do not match.", "danger")
            return render_template("register.html")

        hashed_password = generate_password_hash(password)

        try:
            conn = sqlite3.connect(DB_FILE)
            cursor = conn.cursor()
            cursor.execute("INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)",
                           (full_name, email, hashed_password))
            conn.commit()
            flash("Registered Successfully! Please log in.", "success")
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash("Email already exists. Please use a different email or log in.", "danger")
        finally:
            conn.close()

    return render_template("register.html")

# ---------- Login ----------
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE email=?", (email,))
        user = cursor.fetchone()
        conn.close()

        if user and check_password_hash(user[3], password):
            session['user_id'] = user[0] # Store user ID in session
            session['user_name'] = user[1] # Store full name in session
            flash(f"Welcome, {user[1]}!", "success")
            return redirect(url_for('dashboard'))
        else:
            flash("Invalid email or password.", "danger")

    return render_template("login.html")

# ---------- Dashboard ----------
@app.route('/dashboard')
def dashboard():
    if 'user_name' in session:
        return render_template("dashboard.html", username=session['user_name'])
    flash("Please login first.", "warning")
    return redirect(url_for('login'))

# ---------- Logout ----------
@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('user_name', None)
    flash("Logged out successfully.", "info")
    return redirect(url_for('login'))

# ---------- Notices ----------
@app.route('/notices')
def notices():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT n.id, n.title, n.content, n.publish_date, u.full_name FROM notices n JOIN users u ON n.author_id = u.id ORDER BY n.publish_date DESC")
    notices_data = cursor.fetchall()
    conn.close()
    return render_template("notices.html", notices=notices_data)

@app.route('/add_notice', methods=['GET', 'POST'])
def add_notice():
    if 'user_id' not in session:
        flash("You need to be logged in to add a notice.", "warning")
        return redirect(url_for('login'))

    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        publish_date = request.form['publish_date'] # Or use datetime.now()
        author_id = session['user_id']

        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO notices (title, content, publish_date, author_id) VALUES (?, ?, ?, ?)",
                       (title, content, publish_date, author_id))
        conn.commit()
        conn.close()
        flash("Notice added successfully!", "success")
        return redirect(url_for('notices'))
    return render_template("add_notice.html") # You'll need to create this HTML file

# ---------- Events ----------
@app.route('/events')
def events():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT e.id, e.title, e.description, e.event_date, e.event_time, e.location, u.full_name FROM events e JOIN users u ON e.organizer_id = u.id ORDER BY e.event_date ASC")
    events_data = cursor.fetchall()
    conn.close()
    return render_template("events.html", events=events_data)

@app.route('/add_event', methods=['GET', 'POST'])
def add_event():
    if 'user_id' not in session:
        flash("You need to be logged in to add an event.", "warning")
        return redirect(url_for('login'))

    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        event_date = request.form['event_date']
        event_time = request.form['event_time']
        location = request.form['location']
        organizer_id = session['user_id']

        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO events (title, description, event_date, event_time, location, organizer_id) VALUES (?, ?, ?, ?, ?, ?)",
                       (title, description, event_date, event_time, location, organizer_id))
        conn.commit()
        conn.close()
        flash("Event added successfully!", "success")
        return redirect(url_for('events'))
    return render_template("add_event.html") # You'll need to create this HTML file

# ---------- Faculty ----------
@app.route('/faculty')
def faculty():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, department, email, phone, bio FROM faculty ORDER BY name ASC")
    faculty_data = cursor.fetchall()
    conn.close()
    return render_template("faculty.html", faculty=faculty_data)

@app.route('/add_faculty', methods=['GET', 'POST'])
def add_faculty():
    # You might want to restrict this to admin users only
    if 'user_id' not in session:
        flash("You need to be logged in to add faculty.", "warning")
        return redirect(url_for('login'))

    if request.method == 'POST':
        name = request.form['name']
        department = request.form['department']
        email = request.form['email']
        phone = request.form['phone']
        bio = request.form['bio']

        try:
            conn = sqlite3.connect(DB_FILE)
            cursor = conn.cursor()
            cursor.execute("INSERT INTO faculty (name, department, email, phone, bio) VALUES (?, ?, ?, ?, ?)",
                           (name, department, email, phone, bio))
            conn.commit()
            flash("Faculty member added successfully!", "success")
            return redirect(url_for('faculty'))
        except sqlite3.IntegrityError:
            flash("Faculty email already exists.", "danger")
        finally:
            conn.close()
    return render_template("add_faculty.html") # You'll need to create this HTML file

# ---------- Timetable ----------
@app.route('/timetable')
def timetable():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT t.id, t.day_of_week, t.start_time, t.end_time, t.subject, f.name, t.room FROM timetable t LEFT JOIN faculty f ON t.faculty_id = f.id ORDER BY t.day_of_week, t.start_time ASC")
    timetable_data = cursor.fetchall()
    conn.close()
    return render_template("timetable.html", timetable=timetable_data)

@app.route('/add_timetable_entry', methods=['GET', 'POST'])
def add_timetable_entry():
    # You might want to restrict this to admin users only
    if 'user_id' not in session:
        flash("You need to be logged in to add timetable entries.", "warning")
        return redirect(url_for('login'))

    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT id, name FROM faculty ORDER BY name ASC")
    faculty_members = cursor.fetchall()
    conn.close()

    if request.method == 'POST':
        day_of_week = request.form['day_of_week']
        start_time = request.form['start_time']
        end_time = request.form['end_time']
        subject = request.form['subject']
        faculty_id = request.form['faculty_id']
        room = request.form['room']

        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO timetable (day_of_week, start_time, end_time, subject, faculty_id, room) VALUES (?, ?, ?, ?, ?, ?)",
                       (day_of_week, start_time, end_time, subject, faculty_id, room))
        conn.commit()
        conn.close()
        flash("Timetable entry added successfully!", "success")
        return redirect(url_for('timetable'))
    return render_template("add_timetable_entry.html", faculty_members=faculty_members) # You'll need to create this HTML file

# ---------- Contact ----------
@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        subject = request.form['subject']
        message = request.form['message']

        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO contacts (name, email, subject, message) VALUES (?, ?, ?, ?)",
                       (name, email, subject, message))
        conn.commit()
        conn.close()
        flash("Your message has been sent successfully!", "success")
        return redirect(url_for('contact'))
    return render_template("contact.html")

# ---------- Run ----------
if __name__ == '__main__':
    init_db() # Ensure users table is created if not already
    # It's better to run database.py separately to create all tables initially
    app.run(debug=True)
